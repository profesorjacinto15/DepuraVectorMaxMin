import java.util.Random;
import java.util.Scanner;

public class OperaVector {
    public static void main(String[] args) {
        int[] numeros = generaNumeros();
        imprimeNumeros("Numeros del sorteo ", numeros);
        //Promedio
        System.out.println("Promedio: "+ promedio(numeros));
        //Maximo
        System.out.println("Máximo: "+ maximo(numeros));
        //Minimo
        System.out.println("Mínimo: "+ minimo(numeros));

    }
    public static int[] generaNumeros() {
        Random alea = new Random();
        Scanner tec = new Scanner(System.in);
        System.out.print("Introduce la cantidad de números: ");
        int n = tec.nextInt();
        int[] num = new int[n];
        for (int i=0; i< num.length; i++) {
            num[i] = alea.nextInt(100);
        }
        return num;
    }
    public static void imprimeNumeros(String mesg, int[] nume) {
        System.out.println(mesg);
        for(int i=0; i<nume.length; i++) {
            System.out.print(nume[i] + " ");
        }
        System.out.println();
    }
    public static int promedio(int[] nums) {
        int acumula = 0;
        for (int i=0; i<nums.length; i++) {
            acumula +=  nums[i];
        }
        int promedio = acumula / nums.length;
        return promedio;
    }
    public static int maximo(int[] nums) {
        int max = Integer.MIN_VALUE;
        for (int i=0; i< nums.length; i++) {
            if (max < nums[i]) {
                max = nums[i];
            }
        }
        return max;
    }
    public static int minimo(int[] nums) {
        int min = Integer.MAX_VALUE;
        for (int i=0; i< nums.length; i++) {
            if (min > nums[i]) {
                min = nums[i];
            }
        }
        return min;
    }
}
